# VPN Glass

Flutter-клиент в стиле «стекло + неон»: плиточный экран Brokers, глаз-кнопка,
живой график скорости, VLESS/Reality и Trojan через Xray (flutter_v2ray),
TLS-фрагментация включена по умолчанию.

## Структура

```
lib/
  main.dart                  вкладки Home / Brokers
  core/theme.dart            цвета, тема
  core/glass.dart            GlassCard (BackdropFilter), фон со свечением
  models/models.dart         Broker, ServerItem, список брокеров
  services/db.dart           SQLite: транзакции, индексы, сортировка, очистка
  services/broker_service.dart  загрузка с GitHub + парсинг в isolate
  services/vpn_controller.dart  Xray, фрагментация, пингер
  widgets/eye_button.dart    кнопка-глаз с пульсацией
  widgets/speed_graph.dart   график скорости
  screens/                   home, brokers, servers
```

## Запуск

```
flutter create . --platforms=android,ios
flutter pub get
flutter run
```

## Android

В `android/app/src/main/AndroidManifest.xml` добавь:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

`minSdkVersion` должен быть 21 или выше (требование flutter_v2ray).

## iOS

Для VPN на iOS нужен отдельный Network Extension target (Packet Tunnel),
платная учётная запись Apple Developer и capability Network Extensions.
Без него интерфейс работает, но подключиться на iOS не получится.
Настройка описана в документации flutter_v2ray.

## Фрагментация

Параметры в `VpnController`: `fragLength = '10-30'`, `fragInterval = '10-20'`.
Конфиг добавляет freedom-outbound `fragment-out` с `packets: tlshello` и
направляет через него основной прокси (`sockopt.dialerProxy`).

## Что проверить

- Ссылки брокеров в `models.dart`: репозитории могут переехать.
- Имена методов flutter_v2ray (`parseFromURL`, `getServerDelay`,
  `startV2Ray`) сверь с установленной версией: API плагина менялся.
- Иконки и графику оригинала я не копировал: глаз нарисован кодом.
