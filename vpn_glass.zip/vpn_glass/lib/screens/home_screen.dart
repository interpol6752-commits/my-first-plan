import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/glass.dart';
import '../core/theme.dart';
import '../services/vpn_controller.dart';
import '../widgets/eye_button.dart';
import '../widgets/speed_graph.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  String _fmt(double bytesPerSec) {
    if (bytesPerSec > 1024 * 1024) {
      return '${(bytesPerSec / 1048576).toStringAsFixed(1)} MB/s';
    }
    return '${(bytesPerSec / 1024).toStringAsFixed(0)} KB/s';
  }

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnController>();
    final status = vpn.busy
        ? 'ПОДКЛЮЧЕНИЕ...'
        : vpn.connected
            ? 'ЗАЩИЩЕНО'
            : 'ОТКЛЮЧЕНО';
    final color = vpn.connected ? AppColors.neon : AppColors.textDim;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 0),
        child: Column(
          children: [
            Text('VPN GLASS',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    letterSpacing: 6,
                    fontWeight: FontWeight.w700,
                    color: AppColors.neon)),
            const Spacer(),
            EyeButton(
              connected: vpn.connected,
              busy: vpn.busy,
              onTap: vpn.toggle,
            ),
            const SizedBox(height: 18),
            Text(status,
                style: TextStyle(
                    fontSize: 22,
                    letterSpacing: 3,
                    fontWeight: FontWeight.w700,
                    color: color)),
            const SizedBox(height: 6),
            Text(
              vpn.selected?.name ?? 'Сервер не выбран',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.textDim, fontSize: 15),
            ),
            if (vpn.error != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(vpn.error!,
                    style: const TextStyle(color: AppColors.danger)),
              ),
            const Spacer(),
            Row(
              children: [
                _speed('↓', _fmt(vpn.down.last), AppColors.neon),
                const SizedBox(width: 10),
                _speed('↑', _fmt(vpn.up.last), Colors.white70),
              ],
            ),
            const SizedBox(height: 10),
            SpeedGraph(down: vpn.down, up: vpn.up),
            const SizedBox(height: 14),
          ],
        ),
      ),
    );
  }

  Widget _speed(String arrow, String v, Color c) => Expanded(
        child: GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
          child: Row(
            children: [
              Text(arrow, style: TextStyle(color: c, fontSize: 20)),
              const SizedBox(width: 8),
              Text(v,
                  style: TextStyle(
                      color: c, fontSize: 16, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      );
}
