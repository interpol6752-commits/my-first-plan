import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/theme.dart';
import '../models/models.dart';
import '../services/broker_service.dart';
import '../services/db.dart';

/// Экран Brokers: сетка 2 колонки. Тап по плитке скачивает подписку.
class BrokersScreen extends StatefulWidget {
  final void Function(Broker) onOpen;
  const BrokersScreen({super.key, required this.onOpen});

  @override
  State<BrokersScreen> createState() => _BrokersScreenState();
}

class _BrokersScreenState extends State<BrokersScreen> {
  final _service = BrokerService();
  Map<String, int> _counts = {};
  final Set<String> _loading = {};

  @override
  void initState() {
    super.initState();
    _refreshCounts();
  }

  Future<void> _refreshCounts() async {
    final c = await Db.instance.counts();
    if (mounted) setState(() => _counts = c);
  }

  Future<void> _download(Broker b) async {
    if (_loading.contains(b.id)) return;
    setState(() => _loading.add(b.id));
    try {
      final items = await _service.fetch(b);
      await Db.instance.replaceBroker(b.id, items);
      await _refreshCounts();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${b.name}: загружено ${items.length}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${b.name}: ошибка $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading.remove(b.id));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('BROKERS',
                style: TextStyle(
                    fontSize: 24,
                    letterSpacing: 4,
                    fontWeight: FontWeight.w700,
                    color: AppColors.neon)),
            const SizedBox(height: 4),
            const Text('Тап: скачать подписку. Удержание: открыть серверы.',
                style: TextStyle(color: AppColors.textDim)),
            const SizedBox(height: 14),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.only(bottom: 16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.95,
                ),
                itemCount: kBrokers.length,
                itemBuilder: (_, i) {
                  final b = kBrokers[i];
                  final count = _counts[b.id] ?? 0;
                  return _BrokerTile(
                    broker: b,
                    count: count,
                    loading: _loading.contains(b.id),
                    onTap: () => _download(b),
                    onLongPress: () => widget.onOpen(b),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BrokerTile extends StatelessWidget {
  final Broker broker;
  final int count;
  final bool loading;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const _BrokerTile({
    required this.broker,
    required this.count,
    required this.loading,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      active: count > 0,
      onTap: onTap,
      onLongPress: onLongPress,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(IconData(broker.iconCode, fontFamily: 'MaterialIcons'),
                  color: AppColors.neon, size: 30),
              const Spacer(),
              if (loading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: AppColors.neon),
                ),
            ],
          ),
          const SizedBox(height: 10),
          Text(broker.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style:
                  const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Expanded(
            child: Text(broker.description,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style:
                    const TextStyle(color: AppColors.textDim, fontSize: 13)),
          ),
          Text('$count серверов',
              style: const TextStyle(
                  color: AppColors.neon, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
