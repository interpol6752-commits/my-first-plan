import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/glass.dart';
import '../core/theme.dart';
import '../models/models.dart';
import '../services/db.dart';
import '../services/vpn_controller.dart';

/// Серверы выбранного брокера: плитки с пингом, пингер, очистка мёртвых.
class ServersScreen extends StatefulWidget {
  final Broker broker;
  final VoidCallback onSelected;
  const ServersScreen({super.key, required this.broker, required this.onSelected});

  @override
  State<ServersScreen> createState() => _ServersScreenState();
}

class _ServersScreenState extends State<ServersScreen> {
  List<ServerItem> _items = [];
  bool _pinging = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await Db.instance.servers(widget.broker.id);
    if (mounted) setState(() => _items = l);
  }

  Future<void> _ping() async {
    setState(() => _pinging = true);
    await context.read<VpnController>().pingAll(_items);
    await _load();
    if (mounted) setState(() => _pinging = false);
  }

  Future<void> _clean() async {
    await Db.instance.removeDead(widget.broker.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnController>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text(widget.broker.name),
        actions: [
          IconButton(
            tooltip: 'Удалить мёртвые',
            icon: const Icon(Icons.cleaning_services),
            onPressed: _clean,
          ),
          IconButton(
            tooltip: 'Пинг',
            icon: _pinging
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppColors.neon))
                : const Icon(Icons.speed, color: AppColors.neon),
            onPressed: _pinging ? null : _ping,
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(14),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.7,
        ),
        itemCount: _items.length,
        itemBuilder: (_, i) {
          final s = _items[i];
          final isSel = vpn.selected?.link == s.link;
          final pingColor = s.alive
              ? AppColors.neon
              : (s.ping == -2 ? AppColors.danger : AppColors.textDim);
          return GlassCard(
            active: isSel,
            padding: const EdgeInsets.all(10),
            onTap: () {
              vpn.select(s);
              widget.onSelected();
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 14)),
                const Spacer(),
                Row(
                  children: [
                    Text(s.protocol.toUpperCase(),
                        style: const TextStyle(
                            color: AppColors.textDim, fontSize: 12)),
                    const Spacer(),
                    Text(
                      s.alive ? '${s.ping} ms' : (s.ping == -2 ? 'dead' : '—'),
                      style: TextStyle(
                          color: pingColor, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
