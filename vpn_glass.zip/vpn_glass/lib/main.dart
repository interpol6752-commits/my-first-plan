import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/glass.dart';
import 'core/theme.dart';
import 'models/models.dart';
import 'screens/brokers_screen.dart';
import 'screens/home_screen.dart';
import 'screens/servers_screen.dart';
import 'services/vpn_controller.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => VpnController(),
      child: const App(),
    ),
  );
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'VPN Glass',
        theme: buildTheme(),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;

  void _openServers(Broker b) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => GlowBackground(
        child: ServersScreen(
          broker: b,
          onSelected: () {
            Navigator.of(context).pop();
            setState(() => _tab = 0);
          },
        ),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: GlowBackground(
        child: IndexedStack(
          index: _tab,
          children: [
            const HomeScreen(),
            BrokersScreen(onOpen: _openServers),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.visibility_outlined),
              selectedIcon: Icon(Icons.visibility, color: AppColors.neon),
              label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.grid_view_outlined),
              selectedIcon: Icon(Icons.grid_view, color: AppColors.neon),
              label: 'Brokers'),
        ],
      ),
    );
  }
}
