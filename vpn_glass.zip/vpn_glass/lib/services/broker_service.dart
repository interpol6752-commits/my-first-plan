import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/models.dart';

/// Скачивает подписку из GitHub и парсит vless:// и trojan:// ссылки.
class BrokerService {
  Future<List<ServerItem>> fetch(Broker b) async {
    final res =
        await http.get(Uri.parse(b.url)).timeout(const Duration(seconds: 30));
    if (res.statusCode != 200) {
      throw Exception('HTTP ${res.statusCode}');
    }
    // Парсинг в отдельном изоляте, чтобы не фризить UI.
    return compute(_parse, _Job(b.id, res.body));
  }
}

class _Job {
  final String broker;
  final String body;
  _Job(this.broker, this.body);
}

List<ServerItem> _parse(_Job job) {
  var text = job.body.trim();
  if (!text.contains('://')) {
    // Подписка целиком в base64
    try {
      text = utf8.decode(base64.decode(base64.normalize(text)));
    } catch (_) {}
  }
  final out = <ServerItem>[];
  final seen = <String>{};
  for (final raw in const LineSplitter().convert(text)) {
    final line = raw.trim();
    final proto = line.startsWith('vless://')
        ? 'vless'
        : line.startsWith('trojan://')
            ? 'trojan'
            : null;
    if (proto == null || !seen.add(line)) continue;
    String host = '?';
    String name = proto.toUpperCase();
    try {
      final u = Uri.parse(line);
      host = u.host;
      if (u.fragment.isNotEmpty) name = Uri.decodeComponent(u.fragment);
    } catch (_) {}
    out.add(ServerItem(
      broker: job.broker,
      name: name,
      protocol: proto,
      host: host,
      link: line,
    ));
  }
  return out;
}
