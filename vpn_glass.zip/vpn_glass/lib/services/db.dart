import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

/// Локальная база серверов. Вставка одной транзакцией + индексы,
/// чтобы 200+ записей не вызывали лагов.
class Db {
  Db._();
  static final Db instance = Db._();
  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'servers.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (d, _) async {
        await d.execute('''
          CREATE TABLE servers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            broker TEXT NOT NULL,
            name TEXT NOT NULL,
            protocol TEXT NOT NULL,
            host TEXT NOT NULL,
            link TEXT NOT NULL UNIQUE,
            ping INTEGER NOT NULL DEFAULT -1
          )''');
        await d.execute('CREATE INDEX idx_broker ON servers(broker)');
        await d.execute('CREATE INDEX idx_ping ON servers(ping)');
      },
    );
  }

  /// Заменяет все серверы брокера новым списком.
  Future<void> replaceBroker(String broker, List<ServerItem> items) async {
    final d = await db;
    await d.transaction((txn) async {
      await txn.delete('servers', where: 'broker = ?', whereArgs: [broker]);
      final batch = txn.batch();
      for (final s in items) {
        batch.insert('servers', s.toMap(),
            conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      await batch.commit(noResult: true);
    });
  }

  Future<Map<String, int>> counts() async {
    final d = await db;
    final rows = await d
        .rawQuery('SELECT broker, COUNT(*) c FROM servers GROUP BY broker');
    return {for (final r in rows) r['broker'] as String: r['c'] as int};
  }

  /// Живые сверху (по возрастанию пинга), затем непроверенные, затем мёртвые.
  Future<List<ServerItem>> servers(String broker) async {
    final d = await db;
    final rows = await d.query(
      'servers',
      where: 'broker = ?',
      whereArgs: [broker],
      orderBy: 'CASE WHEN ping >= 0 THEN 0 WHEN ping = -1 THEN 1 ELSE 2 END, ping',
    );
    return rows.map(ServerItem.fromMap).toList();
  }

  Future<void> setPing(int id, int ping) async {
    final d = await db;
    await d.update('servers', {'ping': ping}, where: 'id = ?', whereArgs: [id]);
  }

  /// Быстрая очистка мёртвых серверов.
  Future<int> removeDead(String broker) async {
    final d = await db;
    return d.delete('servers',
        where: 'broker = ? AND ping = -2', whereArgs: [broker]);
  }
}
