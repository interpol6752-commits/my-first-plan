import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Большая круглая кнопка в виде стилизованного глаза.
/// Подключено: ободок и зрачок пульсируют зелёным.
class EyeButton extends StatefulWidget {
  final bool connected;
  final bool busy;
  final VoidCallback onTap;
  final double size;

  const EyeButton({
    super.key,
    required this.connected,
    required this.busy,
    required this.onTap,
    this.size = 240,
  });

  @override
  State<EyeButton> createState() => _EyeButtonState();
}

class _EyeButtonState extends State<EyeButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => CustomPaint(
            painter: _EyePainter(
              t: _c.value,
              connected: widget.connected,
              busy: widget.busy,
            ),
          ),
        ),
      ),
    );
  }
}

class _EyePainter extends CustomPainter {
  final double t;
  final bool connected;
  final bool busy;
  _EyePainter({required this.t, required this.connected, required this.busy});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final pulse = (math.sin(t * 2 * math.pi) + 1) / 2; // 0..1
    final color = connected
        ? AppColors.neon
        : (busy ? AppColors.neon.withOpacity(0.6) : AppColors.textDim);

    // Внешнее свечение
    if (connected || busy) {
      canvas.drawCircle(
        c,
        r * (0.92 + 0.06 * pulse),
        Paint()
          ..color = AppColors.neon.withOpacity(0.10 + 0.12 * pulse)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22),
      );
    }

    // Ободок
    canvas.drawCircle(
      c,
      r * 0.88,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = connected ? 3 + 2 * pulse : 2
        ..color = color,
    );

    // Фон кнопки
    canvas.drawCircle(
      c,
      r * 0.82,
      Paint()
        ..shader = RadialGradient(
          colors: [const Color(0xFF0F1F18), AppColors.bg],
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );

    // Контур глаза (миндалина)
    final w = r * 1.2;
    final h = r * 0.62;
    final eye = Path()
      ..moveTo(c.dx - w / 2 * 1.25, c.dy)
      ..quadraticBezierTo(c.dx, c.dy - h * 1.2, c.dx + w / 2 * 1.25, c.dy)
      ..quadraticBezierTo(c.dx, c.dy + h * 1.2, c.dx - w / 2 * 1.25, c.dy)
      ..close();
    canvas.drawPath(
      eye,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeJoin = StrokeJoin.round
        ..color = color,
    );

    // Радужка и зрачок
    final irisR = r * 0.30;
    canvas.save();
    canvas.clipPath(eye);
    canvas.drawCircle(
      c,
      irisR,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = color.withOpacity(0.8),
    );
    final pupilR = connected ? irisR * (0.45 + 0.2 * pulse) : irisR * 0.4;
    canvas.drawCircle(
      c,
      pupilR,
      Paint()
        ..color = color
        ..maskFilter = connected
            ? const MaskFilter.blur(BlurStyle.solid, 6)
            : null,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _EyePainter old) =>
      old.t != t || old.connected != connected || old.busy != busy;
}
