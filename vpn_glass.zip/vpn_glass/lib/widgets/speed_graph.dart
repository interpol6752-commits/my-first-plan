import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/theme.dart';

/// Живой график скорости: две линии (загрузка/отдача).
class SpeedGraph extends StatelessWidget {
  final List<double> down;
  final List<double> up;
  const SpeedGraph({super.key, required this.down, required this.up});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: SizedBox(
        height: 110,
        child: RepaintBoundary(
          child: CustomPaint(
            size: Size.infinite,
            painter: _GraphPainter(down, up),
          ),
        ),
      ),
    );
  }
}

class _GraphPainter extends CustomPainter {
  final List<double> down;
  final List<double> up;
  _GraphPainter(this.down, this.up);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = AppColors.neon.withOpacity(0.08)
      ..strokeWidth = 1;
    for (var i = 1; i < 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final maxV = [...down, ...up, 1.0].reduce((a, b) => a > b ? a : b);
    _line(canvas, size, down, maxV, AppColors.neon, fill: true);
    _line(canvas, size, up, maxV, Colors.white54);
  }

  void _line(Canvas canvas, Size size, List<double> v, double maxV, Color c,
      {bool fill = false}) {
    if (v.length < 2) return;
    final path = Path();
    for (var i = 0; i < v.length; i++) {
      final x = size.width * i / (v.length - 1);
      final y = size.height - (v[i] / maxV) * (size.height - 6) - 3;
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    if (fill) {
      final area = Path.from(path)
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();
      canvas.drawPath(
        area,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.withOpacity(0.30), c.withOpacity(0.0)],
          ).createShader(Offset.zero & size),
      );
    }
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeJoin = StrokeJoin.round
        ..color = c,
    );
  }

  @override
  bool shouldRepaint(covariant _GraphPainter old) => true;
}
