import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const neon = Color(0xFF00FF66);
  static const neonDim = Color(0xFF0B8F3E);
  static const bg = Color(0xFF050807);
  static const bg2 = Color(0xFF0C1411);
  static const glass = Color(0x990E1A15); // полупрозрачный тёмный
  static const danger = Color(0xFFFF4D4D);
  static const textDim = Color(0xFF8AA396);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.neon,
      secondary: AppColors.neon,
      surface: AppColors.bg2,
    ),
    textTheme: GoogleFonts.rajdhaniTextTheme(base.textTheme).apply(
      bodyColor: Colors.white,
      displayColor: Colors.white,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.transparent,
      indicatorColor: AppColors.neon.withOpacity(0.15),
      labelTextStyle: WidgetStatePropertyAll(
        GoogleFonts.rajdhani(fontWeight: FontWeight.w600),
      ),
    ),
  );
}
