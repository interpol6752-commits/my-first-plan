import 'dart:ui';
import 'package:flutter/material.dart';
import 'theme.dart';

/// Карточка с эффектом матового стекла и тонкой неоновой рамкой.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final bool active;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 18,
    this.active = false,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final border = active
        ? AppColors.neon
        : AppColors.neon.withOpacity(0.25);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Material(
          color: AppColors.glass,
          child: InkWell(
            onTap: onTap,
            onLongPress: onLongPress,
            splashColor: AppColors.neon.withOpacity(0.12),
            child: Container(
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                border: Border.all(color: border, width: active ? 1.4 : 0.8),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: AppColors.neon.withOpacity(0.25),
                          blurRadius: 16,
                        )
                      ]
                    : null,
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

/// Фон с мягкими зелёными свечениями, чтобы стекло было что размывать.
class GlowBackground extends StatelessWidget {
  final Widget child;
  const GlowBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: AppColors.bg),
        Positioned(
          top: -120,
          left: -80,
          child: _blob(320, AppColors.neon.withOpacity(0.10)),
        ),
        Positioned(
          bottom: -140,
          right: -100,
          child: _blob(360, AppColors.neonDim.withOpacity(0.14)),
        ),
        child,
      ],
    );
  }

  Widget _blob(double size, Color c) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [c, Colors.transparent]),
        ),
      );
}
