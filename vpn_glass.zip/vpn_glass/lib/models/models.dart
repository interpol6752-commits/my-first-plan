class Broker {
  final String id;
  final String name;
  final String description;
  final String url;
  final int iconCode; // codePoint из Icons

  const Broker({
    required this.id,
    required this.name,
    required this.description,
    required this.url,
    required this.iconCode,
  });
}

/// Встроенные провайдеры. Проверь актуальность ссылок перед релизом.
const kBrokers = <Broker>[
  Broker(
    id: 'epodonios',
    name: 'Epodonios',
    description: 'v2ray-configs: общий сборник VLESS / Trojan',
    url:
        'https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/All_Configs_Sub.txt',
    iconCode: 0xe3a6, // Icons.visibility
  ),
  Broker(
    id: 'v2rayaggregator',
    name: 'V2RayAggregator',
    description: 'Агрегатор подписок, обновляется автоматически',
    url:
        'https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge.txt',
    iconCode: 0xe2c4, // Icons.hub
  ),
  Broker(
    id: 'barry-far',
    name: 'barry-far',
    description: 'V2ray-Config: проверенные конфигурации',
    url:
        'https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt',
    iconCode: 0xe8e8, // Icons.shield
  ),
];

class ServerItem {
  final int? id;
  final String broker;
  final String name;
  final String protocol;
  final String host;
  final String link;
  final int ping; // -1 не проверен, -2 мёртв

  const ServerItem({
    this.id,
    required this.broker,
    required this.name,
    required this.protocol,
    required this.host,
    required this.link,
    this.ping = -1,
  });

  factory ServerItem.fromMap(Map<String, Object?> m) => ServerItem(
        id: m['id'] as int?,
        broker: m['broker'] as String,
        name: m['name'] as String,
        protocol: m['protocol'] as String,
        host: m['host'] as String,
        link: m['link'] as String,
        ping: m['ping'] as int,
      );

  Map<String, Object?> toMap() => {
        'broker': broker,
        'name': name,
        'protocol': protocol,
        'host': host,
        'link': link,
        'ping': ping,
      };

  bool get alive => ping >= 0;
}
