import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import '../models/models.dart';
import 'db.dart';

/// Управление ядром Xray, пингер и состояние для UI.
class VpnController extends ChangeNotifier {
  late final FlutterV2ray _core;

  bool connected = false;
  bool busy = false;
  ServerItem? selected;
  String? error;

  // Параметры фрагментации (включена по умолчанию)
  bool fragmentEnabled = true;
  String fragLength = '10-30';
  String fragInterval = '10-20';

  final List<double> down = List.filled(40, 0, growable: true);
  final List<double> up = List.filled(40, 0, growable: true);

  VpnController() {
    _core = FlutterV2ray(onStatusChanged: _onStatus);
    _core.initializeV2Ray();
  }

  void _onStatus(V2RayStatus s) {
    connected = s.state == 'CONNECTED';
    down
      ..removeAt(0)
      ..add(s.downloadSpeed.toDouble());
    up
      ..removeAt(0)
      ..add(s.uploadSpeed.toDouble());
    notifyListeners();
  }

  void select(ServerItem s) {
    selected = s;
    notifyListeners();
  }

  /// Собирает полный конфиг Xray из ссылки и добавляет TLS-фрагментацию.
  String buildConfig(String link) {
    final parsed = FlutterV2ray.parseFromURL(link);
    final cfg = jsonDecode(parsed.getFullConfiguration()) as Map<String, dynamic>;
    if (fragmentEnabled) {
      final outbounds = (cfg['outbounds'] as List).cast<Map<String, dynamic>>();
      outbounds.add({
        'tag': 'fragment-out',
        'protocol': 'freedom',
        'settings': {
          'fragment': {
            'packets': 'tlshello',
            'length': fragLength,
            'interval': fragInterval,
          }
        },
      });
      // Первый outbound — прокси; пускаем его через фрагментатор.
      final proxy = outbounds.first;
      final ss = (proxy['streamSettings'] ??= <String, dynamic>{})
          as Map<String, dynamic>;
      final sock = (ss['sockopt'] ??= <String, dynamic>{}) as Map<String, dynamic>;
      sock['dialerProxy'] = 'fragment-out';
    }
    return jsonEncode(cfg);
  }

  Future<void> toggle() async {
    if (busy) return;
    if (connected) {
      _core.stopV2Ray();
      return;
    }
    final s = selected;
    if (s == null) {
      error = 'Выбери сервер на вкладке Servers';
      notifyListeners();
      return;
    }
    busy = true;
    error = null;
    notifyListeners();
    try {
      if (!await _core.requestPermission()) {
        throw Exception('Нет разрешения VPN');
      }
      _core.startV2Ray(
        remark: s.name,
        config: buildConfig(s.link),
        proxyOnly: false,
      );
    } catch (e) {
      error = e.toString();
    }
    busy = false;
    notifyListeners();
  }

  /// Пингер: реальная задержка через ядро, пачками по 8 параллельно.
  Future<void> pingAll(List<ServerItem> items,
      {void Function(ServerItem, int)? onResult}) async {
    const batch = 8;
    for (var i = 0; i < items.length; i += batch) {
      final chunk = items.skip(i).take(batch);
      await Future.wait(chunk.map((s) async {
        int ms;
        try {
          ms = await _core
              .getServerDelay(config: buildConfig(s.link))
              .timeout(const Duration(seconds: 6));
          if (ms <= 0) ms = -2;
        } catch (_) {
          ms = -2;
        }
        if (s.id != null) await Db.instance.setPing(s.id!, ms);
        onResult?.call(s, ms);
      }));
    }
  }
}
